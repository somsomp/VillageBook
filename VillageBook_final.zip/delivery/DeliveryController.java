package com.spring.view.delivery;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spring.biz.delivery.DeliveryVO;
import com.spring.biz.delivery.impl.DeliveryDAO;
import com.spring.biz.delivery.impl.DeliveryDAO2;
import com.spring.biz.user.UserVO;
import com.spring.biz.user.impl.UserDAO;

@Controller
public class DeliveryController {

	@RequestMapping("/delivery.do")
	public String getBoard(DeliveryVO vo, DeliveryDAO boardDAO, Model model) {
		System.out.println("글 상세 페이지");

		model.addAttribute("boardList", boardDAO.getOrdList(vo));
		return "delivery.jsp";
	}
	
	@RequestMapping("/deliveryList.do")
	public String getBoardList(DeliveryVO vo, DeliveryDAO boardDAO, Model model) {
		System.out.println("글 리스트");
		
		model.addAttribute("boardList", boardDAO.getOrdidList(vo));
		return "deliveryList.jsp";
	}
	
	@RequestMapping("/clientDeliveryList.do")
	public String getDeliveryList() {
		return "delivery.jsp";
	}
	
	@RequestMapping("/renewtf.do")
	public String getDelivery(DeliveryVO vo, DeliveryDAO2 delivery, DeliveryDAO boardDAO, Model model) {
		System.out.println("연장 수정");
		delivery.getchange(vo);
		delivery.getchange_DATE(vo);
		model.addAttribute("boardList", boardDAO.getOrdList(vo));
		return "delivery.jsp";
	}
}
