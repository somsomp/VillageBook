package com.spring.biz.delivery.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

import com.spring.biz.common.JDBCUtil;
import com.spring.biz.delivery.DeliveryVO;

// DAO(Data Access Object)
//@Repository("boardDAO")
public class DeliveryDAO {
	// JDBC ���� ����
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	private PreparedStatement stmt2 = null;
	private ResultSet rs2 = null;

	// SQL ��ɾ��
	private final String BOARD_GET = "select * from delivery where ordid=?";
	private final String BOARD_LIST = "select * from delivery order by ordid desc";

	private final String ORDID_LIST = "select distinct ordid, orderdate, startdate, returndate, shipping from delivery";
	private final String ORD_LIST = "select * from delivery where ordid=?";

	// �� �� ��ȸ
	public DeliveryVO getBoard(DeliveryVO vo) {
		System.out.println("===> JDBC getBoard()");
		DeliveryVO board = null;
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(BOARD_GET);
			stmt.setLong(1, vo.getOrdid());
			rs = stmt.executeQuery();
			if (rs.next()) {
				board = new DeliveryVO();
				board.setOrdid(rs.getLong(1));
				board.setIsbn(rs.getLong(2));
				board.setCid(rs.getString(3));
				board.setLid(rs.getLong(4));
				board.setOrdercnt(rs.getLong(5));
				board.setOrdmoney(rs.getLong(6));
				board.setOrderdate(rs.getDate(7));
				board.setStartdate(rs.getDate(8));
				board.setReturndate(rs.getDate(9));
				board.setShipping(rs.getLong(10));
				board.setRenewtf(rs.getString(11));
				board.setReturnwer(rs.getString(12));
				board.setBookname(rs.getString(13));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return board;
	}

	// �� ��� ��ȸ
	public List<DeliveryVO> getBoardList(DeliveryVO vo) {
		System.out.println("===> JDBC getBoardList()");
		List<DeliveryVO> boardList = new ArrayList<DeliveryVO>();
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(BOARD_LIST);
			rs = stmt.executeQuery();
			while (rs.next()) {
				DeliveryVO board = new DeliveryVO();
				board.setOrdid(rs.getLong(1));
				board.setIsbn(rs.getLong(2));
				board.setCid(rs.getString(3));
				board.setLid(rs.getLong(4));
				board.setOrdercnt(rs.getLong(5));
				board.setOrdmoney(rs.getLong(6));
				board.setOrderdate(rs.getDate(7));
				board.setStartdate(rs.getDate(8));
				board.setReturndate(rs.getDate(9));
				board.setShipping(rs.getLong(10));
				board.setRenewtf(rs.getString(11));
				board.setReturnwer(rs.getString(12));
				board.setBookname(rs.getString(13));
				boardList.add(board);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return boardList;
	}
	
	public List<DeliveryVO> getOrdidList(DeliveryVO vo){
		System.out.println("===> JDBC getOrdidList()");
		List<DeliveryVO> boardList = new ArrayList<DeliveryVO>();
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(ORDID_LIST);
			rs = stmt.executeQuery();
			while (rs.next()) {
				DeliveryVO board = new DeliveryVO();
				board.setOrdid(rs.getLong(1));
				board.setOrderdate(rs.getDate(2));
				board.setStartdate(rs.getDate(3));
				board.setReturndate(rs.getDate(4));
				board.setShipping(rs.getLong(5));
				boardList.add(board);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return boardList;
	}

	public List<DeliveryVO> getOrdList(DeliveryVO vo) {
		System.out.println("===> JDBC getOrdList()");
		List<DeliveryVO> boardList = new ArrayList<DeliveryVO>();
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(ORD_LIST);
			stmt.setLong(1, vo.getOrdid());
			rs = stmt.executeQuery();
			while (rs.next()) {
				DeliveryVO board = new DeliveryVO();
				board.setOrdid(rs.getLong(1));
				board.setIsbn(rs.getLong(2));
				board.setCid(rs.getString(3));
				board.setLid(rs.getLong(4));
				board.setOrdercnt(rs.getLong(5));
				board.setOrdmoney(rs.getLong(6));
				board.setOrderdate(rs.getDate(7));
				board.setStartdate(rs.getDate(8));
				board.setReturndate(rs.getDate(9));
				board.setShipping(rs.getLong(10));
				board.setRenewtf(rs.getString(11));
				board.setReturnwer(rs.getString(12));
				board.setBookname(rs.getString(13));
				boardList.add(board);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return boardList;
	}
}