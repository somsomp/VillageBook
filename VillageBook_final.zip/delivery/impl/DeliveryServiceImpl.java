package com.spring.biz.delivery.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.biz.delivery.DeliveryService;
import com.spring.biz.delivery.DeliveryVO;

@Service("boardService")
public class DeliveryServiceImpl implements DeliveryService {
	@Autowired
	private DeliveryDAO boardDAO;

	public void insertBoard(DeliveryVO vo) {
//		if (vo.getSeq() == 0) {
//			throw new IllegalArgumentException("0�� ���� ����� �� �����ϴ�.");
//		}
//		boardDAO.insertBoard(vo);
	}

	public void updateBoard(DeliveryVO vo) {
//		boardDAO.updateBoard(vo);
	}

	public void deleteBoard(DeliveryVO vo) {
//		boardDAO.deleteBoard(vo);
	}

	public DeliveryVO getBoard(DeliveryVO vo) {
		return boardDAO.getBoard(vo);
	}

	public List<DeliveryVO> getBoardList(DeliveryVO vo) {
		return boardDAO.getBoardList(vo);
	}
}