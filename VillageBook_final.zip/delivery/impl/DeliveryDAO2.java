package com.spring.biz.delivery.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.spring.biz.common.JDBCUtil;
import com.spring.biz.delivery.DeliveryVO;

public class DeliveryDAO2 {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	private final String RENE_CHANGE = "update delivery set renewtf='Y' where ordid=?";
	private final String CHANGE_DATE = "update delivery set RETURNDATE = RETURNDATE+7 where ordid=?";
	
	public List<DeliveryVO> getchange(DeliveryVO vo) {
		System.out.println("===> JDBC DeliveryDAO getchange()");
		List<DeliveryVO> boardList = new ArrayList<DeliveryVO>();
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(RENE_CHANGE);
			stmt.setLong(1, vo.getOrdid());
			System.out.println(vo.getOrdid());
			rs = stmt.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return boardList;
	}
	
	public List<DeliveryVO> getchange_DATE(DeliveryVO vo) {
		System.out.println("===> JDBC DeliveryDAO getcahnge_DATE()");
		List<DeliveryVO> boardList = new ArrayList<DeliveryVO>();
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(CHANGE_DATE);
			stmt.setLong(1, vo.getOrdid());
			System.out.println(vo.getReturndate());
			rs = stmt.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return boardList;
	}
}