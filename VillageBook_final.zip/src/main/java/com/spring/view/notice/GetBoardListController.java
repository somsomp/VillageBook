package com.spring.view.notice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spring.biz.notice.NoticeVO;
import com.spring.biz.notice.impl.NoticeDAO;

@Controller
public class GetBoardListController {

	@RequestMapping("/getBoardList.do")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("글 목록 검색 처리");

		NoticeVO vo = new NoticeVO();
		NoticeDAO boardDAO = new NoticeDAO();
		List<NoticeVO> boardList = boardDAO.getBoardList(vo);

		HttpSession session = request.getSession();
		session.setAttribute("boardList", boardList);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("boardList", boardList);
		mav.setViewName("getBoardList.jsp"); // /WEB-INF/bOARD/getBoardList.jsp로 간다! presentation-layer에 의하면.
		return mav;
	}

}
