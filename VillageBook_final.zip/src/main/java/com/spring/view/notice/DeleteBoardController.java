package com.spring.view.notice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.biz.notice.NoticeVO;
import com.spring.biz.notice.impl.NoticeDAO;

@Controller
public class DeleteBoardController{

	@RequestMapping("/deleteBoard.do")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("글 삭제 처리");

		String seq = request.getParameter("seq");

		NoticeVO vo = new NoticeVO();
		vo.setSeq(Integer.parseInt(seq));

		NoticeDAO boardDAO = new NoticeDAO();
		boardDAO.deleteBoard(vo);

		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:getBoardList.do");
		return mav;
	}

}
