package com.spring.view.cart;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PayController {

	@RequestMapping("/order.do")
	public String order(int sum, Model model){
		System.out.println(sum);
		model.addAttribute("sum", sum);
		System.out.println(model.containsAttribute("sum"));
		return "order.jsp";
	}
	
	@RequestMapping("/payment.do")
	public String payment(Model model){
		System.out.println(model.containsAttribute("sum"));
		//delivery에 넣을 정보들을 여기서 받아와야 한다고요.....
		return "paydone.jsp";
	}
}