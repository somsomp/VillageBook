package com.spring.view.cart;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.spring.biz.cart.CartService;
import com.spring.biz.cart.CartVO;

@Controller
//@SessionAttributes("cart")
public class CartController {
	@Autowired
	private CartService cartService;

	@RequestMapping("/insertCart.do")
	public String insertCart(CartVO vo) throws IOException {
		cartService.insertCart(vo);
		return "getCart.do";
	}
	
	@RequestMapping("/updateCart.do")
	public String updateCart(CartVO vo) throws IOException {
		cartService.updateCart(vo);
		return "getCart.do";
	}
	
	@RequestMapping("/deleteCart.do")
	public String deleteCart(CartVO vo) {
		cartService.deleteCart(vo);
		return "getCart.do";
	}

	@RequestMapping("/getCart.do")
	public String getCart(CartVO vo, Model model, HttpSession session) {
		model.addAttribute("cartList", cartService.getCart(vo));
/////////////////////////////////////////////////
//		String cid = (String) session.getAttribute("cid");
//		User_InfoVO vo = new User_InfoVO();
//		vo.setCid(cid);
//		model.addAttribute("user", userService.selectUser(vo)..대충 cid로 회원정보 불러와 user에 집어넣는 문장);	
/////////////////////////////////////////////////
		return "getCartList.jsp";
	}
//	
//	@RequestMapping("/payment.do")
//	public String payment() {
//		return "paymentIng.jsp";
//	}
}
