package com.spring.view.user;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.spring.biz.user.UserVO;
import com.spring.biz.user.impl.UserDAO;

@Controller
//@SessionAttributes("user")
public class MainPageController{

	@RequestMapping(value="/mainPage.do", method=RequestMethod.GET)
	public String mainView(@ModelAttribute("user") UserVO vo, UserDAO userDAO, HttpSession session) {
		System.out.println("메인 화면으로 이동");
		return "mainPage.jsp";
	}	

	@RequestMapping(value="/mainPage.do", method=RequestMethod.POST)
	public String mainPage(UserVO vo, UserDAO userDAO, HttpSession session) {
		System.out.println("메인 화면 처리");
		UserVO user = userDAO.getUser(vo);

		return "mainPage.jsp";
	}
}