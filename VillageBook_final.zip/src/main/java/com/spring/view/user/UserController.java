package com.spring.view.user;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.spring.biz.user.UserVO;
import com.spring.biz.user.impl.UserDAO;

@Controller
@SessionAttributes("user")
public class UserController {

	@RequestMapping(value = "/insertUser.do")
	public String insertUser(UserVO vo, UserDAO UserDAO) {
		System.out.println("회원 등록 처리");

		UserDAO userDAO = new UserDAO();
		return "mainPage.jsp";
	}

	@RequestMapping(value = "/updateUser.do", method = RequestMethod.GET)
	public String loginView(@ModelAttribute("user") UserVO vo, Model model) {
		System.out.println("회원정보 수정 화면으로 이동");
		System.out.println(vo.getCid());
		//model.addAttribute("user", attributeValue)
		return "updateUser.jsp";
	}

	// 회원 정보 수정 처리
	@RequestMapping(value = "/updateUser.do", method = RequestMethod.POST)
	public String updateUser(UserVO vo, UserDAO userDAO) {
		System.out.println("회원정보 수정 처리");
		System.out.println("ID: " + vo.getCid());
		System.out.println("PW: " + vo.getCpw());
		System.out.println("이름: " + vo.getCname());
		System.out.println("전화번호: " + vo.getChp());
		System.out.println("주소: " + vo.getCpostcode() + vo.getCaddr1() + vo.getCaddr2());
		userDAO.updateUser(vo);
		return "mainPage.do";
	}

}
