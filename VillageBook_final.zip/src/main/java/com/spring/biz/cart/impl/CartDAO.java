package com.spring.biz.cart.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.spring.biz.cart.CartVO;
import com.spring.biz.common.JDBCUtil;

@Repository("cartDAO")
public class CartDAO {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
	private final String CART_INSERT = "insert into cart values (cart_id.nextval, ?, ?, ?, ?, ?, ?)";
	private final String CART_UPDATE = "update cart set cnt = ? where cartid = ?";
	private final String CART_DELETE = "delete from cart where cartid = ?";
	private final String CART_GET = "select * from cart where cid = ? order by lid";

	public void insertCart(CartVO vo) {
		System.out.println("===> JDBC로 insertCart() 기능처리");
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(CART_INSERT);
			stmt.setInt(1, vo.getCnt());
			stmt.setString(2,  vo.getBookname());
			stmt.setLong(3, vo.getlId());
			stmt.setString(4, vo.getLname());
			stmt.setLong(5, vo.getIsbn());
			stmt.setString(6, vo.getcId());
			stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(stmt, conn);
		}
	}
	
	public void updateCart(CartVO vo) {
		System.out.println("===> JDBC로 updateCart() 기능처리");
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(CART_UPDATE);
			stmt.setInt(1, vo.getCnt());
			stmt.setInt(2, vo.getCartId());
			stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(stmt, conn);
		}
	}
	
	public void deleteCart(CartVO vo) {
		System.out.println("===> JDBC로 deleteCart() 기능처리");
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(CART_DELETE);
			stmt.setInt(1, vo.getCartId());
			stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(stmt, conn);
		}
	}
	
	public List<CartVO> getCart(CartVO vo) {
		System.out.println("===> JDBC로 getCart() 기능처리");
		List<CartVO> cartList = new ArrayList<CartVO>();
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(CART_GET);
			stmt.setString(1, vo.getcId());

			rs = stmt.executeQuery();
			while (rs.next()) {
				CartVO cart = new CartVO();
				cart.setCartId(rs.getInt("CARTID"));
				cart.setCnt(rs.getInt("CNT"));
				cart.setBookname(rs.getString("BOOKNAME"));
				cart.setlId(rs.getLong("LID"));
				cart.setLname(rs.getString("LNAME"));
				cart.setIsbn(rs.getLong("ISBN"));
				cart.setcId(rs.getString("CID"));
				cartList.add(cart);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return cartList;
	}
}
