package com.spring.biz.cart.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.biz.cart.CartService;
import com.spring.biz.cart.CartVO;

@Service("cartService")
public class CartServiceImpl implements CartService{
	@Autowired
	private CartDAO cartDAO;
	
	public void insertCart(CartVO vo) {
		cartDAO.insertCart(vo);
	}
	
	public void updateCart(CartVO vo) {
		cartDAO.updateCart(vo);
	}
	
	public void deleteCart(CartVO vo) {
		cartDAO.deleteCart(vo);
	}
	
	public List<CartVO> getCart(CartVO vo){
		return cartDAO.getCart(vo);
	}
}