
package com.spring.biz.delivery.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

import com.spring.biz.common.JDBCUtil;
import com.spring.biz.delivery.DeliveryVO;
import com.spring.biz.user.UserVO;

//@Repository("boardDAO")
public class DeliveryDAO {

	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;

	private final String ORDID_LIST = "select distinct ordid, orderdate, startdate, returndate, shipping from delivery where cid=?";
	private final String ORD_LIST = "select * from delivery where ordid=?";

	public List<DeliveryVO> getOrdidList(DeliveryVO vo){
		System.out.println("===> JDBC getOrdidList()");
		List<DeliveryVO> boardList = new ArrayList<DeliveryVO>();
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(ORDID_LIST);
			System.out.println("cid : " + vo.getCid());
			stmt.setString(1, vo.getCid());
			rs = stmt.executeQuery();
			while (rs.next()) {
				DeliveryVO board = new DeliveryVO();
				board.setOrdid(rs.getLong(1));
				board.setOrderdate(rs.getDate(2));
				board.setStartdate(rs.getDate(3));
				board.setReturndate(rs.getDate(4));
				board.setShipping(rs.getLong(5));
				boardList.add(board);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return boardList;
	}

	public List<DeliveryVO> getOrdList(DeliveryVO vo) {
		System.out.println("===> JDBC getOrdList()");
		List<DeliveryVO> boardList = new ArrayList<DeliveryVO>();
		try {
			conn = JDBCUtil.getConnection();
			stmt = conn.prepareStatement(ORD_LIST);
			stmt.setLong(1, vo.getOrdid());
			rs = stmt.executeQuery();
			while (rs.next()) {
				DeliveryVO board = new DeliveryVO();
				board.setOrdid(rs.getLong(1));
				board.setIsbn(rs.getLong(2));
				board.setCid(rs.getString(3));
				board.setLid(rs.getLong(4));
				board.setOrdercnt(rs.getLong(5));
				board.setOrdmoney(rs.getLong(6));
				board.setOrderdate(rs.getDate(7));
				board.setStartdate(rs.getDate(8));
				board.setReturndate(rs.getDate(9));
				board.setShipping(rs.getLong(10));
				board.setRenewtf(rs.getString(11));
				board.setReturnwer(rs.getString(12));
				board.setBookname(rs.getString(13));
				boardList.add(board);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(rs, stmt, conn);
		}
		return boardList;
	}
}