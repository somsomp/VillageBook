package com.spring.biz.notice;

import java.util.List;

public interface NoticeService {
	void insertBoard(NoticeVO vo);
	void updatdBoard(NoticeVO vo);
	void deleteBoard(NoticeVO vo);
	NoticeVO getBoard(NoticeVO vo);
	List<NoticeVO> getBoardList(NoticeVO vo);
}
