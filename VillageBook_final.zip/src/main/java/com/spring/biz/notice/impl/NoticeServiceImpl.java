package com.spring.biz.notice.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.biz.notice.NoticeService;
import com.spring.biz.notice.NoticeVO;

//@Service("boardService")
public class NoticeServiceImpl implements NoticeService {

	//@Autowired
	private NoticeDAO boardDAO;
	
	public void setBoardDAO(NoticeDAO boardDAO) {
		this.boardDAO = boardDAO;
	}

	public void insertBoard(NoticeVO vo) {
		boardDAO.insertBoard(vo);
	}

	public void updatdBoard(NoticeVO vo) {
		boardDAO.updateBoard(vo);
	}

	public void deleteBoard(NoticeVO vo) {
		boardDAO.deleteBoard(vo);
	}

	public NoticeVO getBoard(NoticeVO vo) {
		return boardDAO.getBoard(vo);
	}

	public List<NoticeVO> getBoardList(NoticeVO vo) {
		return boardDAO.getBoardList(vo);
	}
}