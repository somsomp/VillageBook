package com.spring.biz.user;

import java.util.List;

public interface UserService {
	public UserVO getUser(UserVO vo);
	void insertUser(UserVO vo);
	void updateUser(UserVO vo);
}
