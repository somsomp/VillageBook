package com.spring.biz.book;

import java.util.List;

public interface BookService {
	void insertBook(BookVO vo);
	void updateBook(BookVO vo);
	void deleteBook(BookVO vo);
	BookVO getBook(BookVO vo);
	List<BookVO> getBookList(BookVO vo);

}
