package com.spring.biz.book.Impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.biz.book.BookService;
import com.spring.biz.book.BookVO;

@Service("bookService")
public class BookServiceImpl implements BookService {

	@Autowired
	private BookDAO bookDAO;

	@Override
	public void insertBook(BookVO vo) {
		// TODO Auto-generated method stub
		bookDAO.insertBoard(vo);
	}

	@Override
	public void updateBook(BookVO vo) {
		// TODO Auto-generated method stub
		bookDAO.updateBoard(vo);
	}

	@Override
	public void deleteBook(BookVO vo) {
		// TODO Auto-generated method stub
		bookDAO.deleteBoard(vo);
	}

	@Override
	public BookVO getBook(BookVO vo) {
		return bookDAO.getBook(vo);
	}

	@Override
	public List<BookVO> getBookList(BookVO vo) {
		return bookDAO.getBookList(vo);
	}
}
