package com.spring.biz.book.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.spring.biz.book.BookVO;
import com.spring.biz.common.JDBCUtil;

@Repository("bookDAO")
public class BookDAO {

	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
    private final String BOARD_INSERT = "insert into book(isbn, bookname, author, publisher, pdate, genre) values((select nvl(max(seq), 0)+1 from booklist),?,?,?)";
    private final String BOARD_UPDATE = "update book set bookname=?, author=? where isbn=?";
    private final String BOARD_DELETE = "delete book where isbn=?";
    private final String BOARD_GET    = "select * from book where isbn=?";
    private final String BOARD_LIST = "select * from book order by isbn desc";
    
    private final String BOARD_LIST_B =
    		"select * from book where bookname like '%'||?||'%' order by isbn desc";
    private final String BOARD_LIST_A = 
    		"select * from book where author like '%' || ? || '%' order by isbn desc";
    private final String BOARD_LIST_P =
    		"select * from book where publisher like '%'||?||'%' order by isbn desc";
    
    //CRUD ����� �޼ҵ� ����
    public void insertBoard(BookVO vo){
        System.out.println("===> JDBC로 insertBoard() 기능 처리");
        try {
            conn = JDBCUtil.getConnection();
            stmt = conn.prepareStatement(BOARD_INSERT);
            stmt.setString(1, vo.getBookname());
            stmt.setString(2, vo.getAuthor());
            stmt.setString(3, vo.getPublisher());
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.close(stmt, conn);
        }
    }
    

    public void updateBoard(BookVO vo){
        System.out.println("===> JDBC로 updateBoard() 기능 처리");
        try {
            conn = JDBCUtil.getConnection();
            stmt = conn.prepareStatement(BOARD_UPDATE);
            stmt.setString(1, vo.getBookname());
            stmt.setString(2, vo.getAuthor());
            stmt.setLong(3, vo.getIsbn());
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.close(stmt, conn);
        }
    }    
    

    public void deleteBoard(BookVO vo){
        System.out.println("===> JDBC로 deleteBoard() 기능 처리");
        try {
            conn = JDBCUtil.getConnection();
            stmt = conn.prepareStatement(BOARD_DELETE);
            stmt.setLong(1, vo.getIsbn());
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.close(stmt, conn);
        }
    }
    
    public BookVO getBook(BookVO vo){
        System.out.println("===> JDBC로 getBook() 기능 처리");
        BookVO book = null;
        try {
            conn = JDBCUtil.getConnection();        
            stmt = conn.prepareStatement(BOARD_GET);
            stmt.setLong(1, vo.getIsbn());
            rs = stmt.executeQuery();
            if(rs.next()){
            	book = new BookVO();
            	book.setIsbn(rs.getLong("ISBN"));
            	book.setBookname(rs.getString("BOOKNAME"));
            	book.setAuthor(rs.getString("AUTHOR"));
            	book.setPublisher(rs.getString("PUBLISHER"));
            	book.setPdate(rs.getDate("PDATE"));
            	book.setGenre(rs.getString("GENRE"));
            }    
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            JDBCUtil.close(rs, stmt, conn);
        }
        return book;
    }
    
    
    
    
    //�� ��� ��ȸ
    public List<BookVO> getBookList(BookVO vo){
    	System.out.println("===>JDBC로 getBoardList() 기능 처리");
    	List<BookVO> bookList = new ArrayList<BookVO>();
    	try {
    		conn = JDBCUtil.getConnection();
    		if(vo.getSearchCondition().equals("BOOKNAME")) {
    			stmt = conn.prepareStatement(BOARD_LIST_B);
    		}else if(vo.getSearchCondition().equals("AUTHOR")) {
    			stmt = conn.prepareStatement(BOARD_LIST_A);
    		}else if(vo.getSearchCondition().equals("PUBLISHER")) {
    			stmt = conn.prepareStatement(BOARD_LIST_P);
    		}
    		stmt.setString(1, vo.getSearchKeyword());
    		rs = stmt.executeQuery();
    		while(rs.next()) {
    			BookVO book = new BookVO();
    			book.setIsbn(rs.getLong("ISBN"));
    			book.setBookname(rs.getString("BOOKNAME"));
    			book.setAuthor(rs.getString("WRITER"));
    			book.setPublisher(rs.getString("PUBLISHER"));
    			book.setPdate(rs.getDate("PDATE"));
    			book.setGenre(rs.getString("GENRE"));
    			bookList.add(book);
    		}
    	}catch(Exception e) {
    		e.printStackTrace();
    	}finally {
    		JDBCUtil.close(rs, stmt, conn);
    	}
    	return bookList;
    }
    
    
}
